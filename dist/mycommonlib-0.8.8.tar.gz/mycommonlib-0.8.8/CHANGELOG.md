# MyCommonLib

## Version 0.8.8

- update required Python in pyproject (>=3.10" -> >=3.10,<4.0")

## Version 0.8.6

- Update requirements
- replace pkg_resources with importlib

## Version 0.8.1 (2025-06-12)

- update dependecies for GitHub security alert digest on setup tolls

## Version 0.8.0 (2025-03-05)

- removed the module version
- imported the semantic-version-tools package

## Version 0.7.8

- removed a dot in the version number

## Version 0.7.7

- fix bug in Vers.short() method

## Version 0.7.6

- fix problem with Python version

## Version 0.7.5

-fix regex expression

## Version 0.7.4

- fix bug in  Python version

## Version 0.7.2

- add test on Vers class
- fixed the regex for the version
- fixed bugs in the comparison methods

## Version 0.7.1

- fix requirements

## Version 0.7.0

- Ported the project to poetry
- version support string version (to get version from pyproject)
- update publish workflow for poetry package

## Version 0.6.0

- Added three functions for the string manipulation:
    - snake_case
    - camel_case
    - sentence_case
- add filemode option to startLog method

## Version 0.5.0

- Update the class Vers. 
    - The patch number is now not mandatory.
    - add the \_\_ne__ method

## Version 0.4.1

- bug fixing

## Version 0.4.0 10/09/2024

- add log_formatter variable to the logger

## Vesrion 0.3.7

- fix log folder existence

## Version 0.3.6

- add check type in dict2Table

## Version 0.3.5

- fix dict2Table
- fix comparison between Versions
- forced int in software mode (compatibility with oter packages)

## Version 0.3.2

- fix log verbosity

## Version 0.2.1

- fix a bug in the set of logger name. required to start the logger

## Version 0.2.0

- fix string for compatibility to Python3.8

## Version 0.1.1.devel.1

- fixed bugs. stable version

## Version 0.1.0.devel.3

- fix the logging when the logger is not initialized

## Version 0.1.0.devel.2

- fis bug in the log caller and verbose display

## Version 0.1.0.devel.1

- first release